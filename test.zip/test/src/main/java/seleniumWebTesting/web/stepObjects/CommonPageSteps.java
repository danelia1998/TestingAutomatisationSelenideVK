package seleniumWebTesting.web.stepObjects;

public class CommonPageSteps {
}
