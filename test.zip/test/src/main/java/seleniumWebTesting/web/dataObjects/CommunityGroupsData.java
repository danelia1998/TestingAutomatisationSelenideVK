package seleniumWebTesting.web.dataObjects;

public interface CommunityGroupsData {

    String
            communityName = "Reddit";

    Integer
            indexOfOpenedMeme = 3;
}
