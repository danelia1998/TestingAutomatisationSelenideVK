package seleniumWebTesting.web.dataObjects;

public interface UrlData {

    String
            loginPageUrl = "https://vk.com/";
}
