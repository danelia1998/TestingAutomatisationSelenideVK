package seleniumWebTesting.web.dataObjects;

public interface CommonData {
    String standartText = "David you must progress everyday!";
}
