
import java.io.IOException;
import java.sql.SQLException;

public class Main{

    public static void main(String[] args)
            throws IOException, InterruptedException, SQLException, ClassNotFoundException {

        //LoginPageSteps data = new LoginPageSteps();
        //data.getDataFromDB();
        // getData.getDataFromExcel();
//        Proxy p=new Proxy();
//        p.setHttpProxy("proxy.hq.tbc:8080");
//        DesiredCapabilities cap=new DesiredCapabilities();
//        cap.setCapability(CapabilityType.PROXY, p);
//        WebDriver driver=new ChromeDriver(cap); //FirefoxDriver(cap);
    }

}
