package seleniumWebTesting.web.tests.News;

import com.codeborne.selenide.Selenide;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import seleniumWebTesting.web.pageObjects.CommunityGroups;
import seleniumWebTesting.web.pageObjects.MassagePage;
import seleniumWebTesting.web.stepObjects.*;
import seleniumWebTesting.web.utils.ChromeRunner;
import static seleniumWebTesting.web.dataObjects.CommunityGroupsData.*;
import static seleniumWebTesting.web.dataObjects.UserData.*;
import org.junit.*;


public class loginTest extends ChromeRunner {

    @Before
    public void loginIntoSystem(){
        loginPageSteps step = new loginPageSteps();
        step.logginIntoSystem(excel.getCellDataNumber(1,0),
                excel.getCellDataString(1, 1));
        System.out.println(excel.getCellDataNumber(1,0));
        System.out.println(excel.getCellDataString(1, 1));

    }

    @After
    public void afterMethod(){
        afterEachSteps closing = new afterEachSteps();
        closing.closeBrowserAndClearCookies();
    }

    @Test
    @DisplayName("Playing Music")
    public void playMusic() throws InterruptedException {

        MusicPageSteps step2 = new MusicPageSteps();
        step2.enterMusicSection();
        step2.searchingMusic(songName);
        step2.playSong();

        SleepingSteps waiting = new SleepingSteps();
        waiting.stopAction(10);
    }

//    @Test
//    @DisplayName("playing music With shuffle mode")
//    public void playMusicWithShuffle() throws InterruptedException {
//
//        MusicPageSteps step2 = new MusicPageSteps();
//        step2.enterMusicSection();
//        step2.shuffleAll();
//
//        SleepingSteps waiting = new SleepingSteps();
//        waiting.stopAction(20);
//
//    }
//
//
//    @Test
//    @DisplayName("Sending Massage")
//    public void sendMassageToPerson() {
//
//        MassagePageSteps step3 = new MassagePageSteps();
//        step3.enterMassageSection();
//        step3.searchPerson(nameOfPerson);
//        step3.sendMassageToPerson(massage);
//        step3.checkingIfMassageWasSendSuccessfully();
//
//    }
//
//    @Test
//    @DisplayName("Community Group search and openning Pics")
//    public void searchingCommunityAndWatchingSomeMemes() throws InterruptedException {
//
//        CommunityGroupsSteps step1 = new CommunityGroupsSteps();
//        step1.enterCommunitySection();
//        step1.searchingCommunity(communityName);
//        step1.choosingCommunity();
//        step1.openingPicByIndexWithTiming(10,2);
//
//    }
//
//    @Test
//    @DisplayName("check if friend exists")
//    public void checkIfFriendExists() {
//
//        FriendPageSteps step0 = new FriendPageSteps();
//        step0.enterFriendsSection();
//        step0.searchPerson(foundPersonName);
//        step0.checkIfItsExists(foundPersonName);
//
//    }
//
//    @Test
//    @DisplayName("play music looking to my massage about feelings")
//    public void playMusicLookingToMyMassageFeelings() throws InterruptedException {
//
//        playMusicLookingToMyFeelingSteps step0 = new playMusicLookingToMyFeelingSteps();
//        step0.enterProfile(someInteger);
//
//    }
}
